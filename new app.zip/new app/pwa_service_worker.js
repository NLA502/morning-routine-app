const CACHE_NAME = 'next-level-advisory-v1.0.0';
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json',
  'https://cdn.tailwindcss.com/3.3.0'
];

// Install event - cache resources
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
      .catch(error => {
        console.log('Cache failed:', error);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Fetch event - serve cached content when offline
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Cache hit - return response
        if (response) {
          return response;
        }

        return fetch(event.request).then(response => {
          // Check if we received a valid response
          if (!response || response.status !== 200 || response.type !== 'basic') {
            return response;
          }

          // Clone the response
          const responseToCache = response.clone();

          caches.open(CACHE_NAME)
            .then(cache => {
              cache.put(event.request, responseToCache);
            });

          return response;
        }).catch(() => {
          // If both cache and network fail, return offline page
          return caches.match('/index.html');
        });
      })
  );
});

// Background sync for when app comes back online
self.addEventListener('sync', event => {
  if (event.tag === 'routine-sync') {
    event.waitUntil(syncRoutineData());
  }
});

// Push notification handling
self.addEventListener('push', event => {
  const options = {
    body: event.data ? event.data.text() : 'Time for your morning routine!',
    icon: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 192"%3E%3Crect width="192" height="192" fill="%233b82f6" rx="20"/%3E%3Cg fill="white"%3E%3Cpath d="M40 160 L60 100 L80 130 L100 80 L120 110 L140 160 Z" opacity="0.9"/%3E%3Cpath d="M50 160 L70 105 L90 135 L110 85 L130 115 L152 160 Z" opacity="0.6"/%3E%3C/g%3E%3Ctext x="96" y="60" font-size="32" text-anchor="middle" fill="white" font-family="Arial, sans-serif" font-weight="bold"%3ENL%3C/text%3E%3Ctext x="96" y="180" font-size="12" text-anchor="middle" fill="white" font-family="Arial, sans-serif"%3EADVISORY%3C/text%3E%3C/svg%3E',
    badge: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"%3E%3Crect width="96" height="96" fill="%233b82f6" rx="10"/%3E%3Ctext x="48" y="60" font-size="40" text-anchor="middle" fill="white"%3E✓%3C/text%3E%3C/svg%3E',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'open-app',
        title: 'Open App',
        icon: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"%3E%3Crect width="96" height="96" fill="%2310b981" rx="10"/%3E%3Ctext x="48" y="60" font-size="40" text-anchor="middle" fill="white"%3E↗%3C/text%3E%3C/svg%3E'
      },
      {
        action: 'dismiss',
        title: 'Dismiss',
        icon: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"%3E%3Crect width="96" height="96" fill="%23ef4444" rx="10"/%3E%3Ctext x="48" y="60" font-size="40" text-anchor="middle" fill="white"%3E✕%3C/text%3E%3C/svg%3E'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification('Next Level Advisory', options)
  );
});

// Handle notification clicks
self.addEventListener('notificationclick', event => {
  event.notification.close();

  if (event.action === 'open-app') {
    event.waitUntil(
      clients.openWindow('/')
    );
  } else if (event.action === 'dismiss') {
    // Just close the notification
    return;
  } else {
    // Default action - open the app
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});

// Sync routine data when back online
async function syncRoutineData() {
  try {
    // Get stored routine data from IndexedDB or localStorage
    const storedData = await getStoredRoutineData();
    
    if (storedData && storedData.length > 0) {
      // Send data to server when online
      await sendDataToServer(storedData);
      
      // Clear stored data after successful sync
      await clearStoredData();
      
      console.log('Routine data synced successfully');
    }
  } catch (error) {
    console.error('Failed to sync routine data:', error);
  }
}

async function getStoredRoutineData() {
  // This would get data from IndexedDB or localStorage
  // For now, return empty array
  return [];
}

async function sendDataToServer(data) {
  // This would send data to your backend server
  // For now, just log it
  console.log('Would send to server:', data);
}

async function clearStoredData() {
  // This would clear the stored data after successful sync
  console.log('Stored data cleared');
}

// Handle app shortcuts
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

// Periodic background sync (if supported)
self.addEventListener('periodicsync', event => {
  if (event.tag === 'daily-reminder') {
    event.waitUntil(sendDailyReminder());
  }
});

async function sendDailyReminder() {
  const now = new Date();
  const hour = now.getHours();
  
  // Send reminder between 6 AM and 9 AM
  if (hour >= 6 && hour <= 9) {
    await self.registration.showNotification('Next Level Advisory', {
      body: 'Good morning! Time to start your daily routine 🌅',
      icon: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 192"%3E%3Crect width="192" height="192" fill="%233b82f6" rx="20"/%3E%3Cg fill="white"%3E%3Cpath d="M40 160 L60 100 L80 130 L100 80 L120 110 L140 160 Z" opacity="0.9"/%3E%3Cpath d="M50 160 L70 105 L90 135 L110 85 L130 115 L152 160 Z" opacity="0.6"/%3E%3C/g%3E%3Ctext x="96" y="60" font-size="32" text-anchor="middle" fill="white" font-family="Arial, sans-serif" font-weight="bold"%3ENL%3C/text%3E%3Ctext x="96" y="180" font-size="12" text-anchor="middle" fill="white" font-family="Arial, sans-serif"%3EADVISORY%3C/text%3E%3C/svg%3E',
      badge: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"%3E%3Crect width="96" height="96" fill="%233b82f6" rx="10"/%3E%3Ctext x="48" y="60" font-size="40" text-anchor="middle" fill="white"%3E⏰%3C/text%3E%3C/svg%3E',
      tag: 'daily-reminder'
    });
  }
}